/*
 * progressbar_tickets.js
 */
(function($) {

module("progressbar: tickets");

})(jQuery);

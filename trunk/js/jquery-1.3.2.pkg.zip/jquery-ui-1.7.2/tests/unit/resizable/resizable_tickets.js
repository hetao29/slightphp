/*
 * resizable_tickets.js
 */
(function($) {

module("resizable: tickets");

})(jQuery);
